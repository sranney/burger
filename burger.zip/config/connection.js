var mysql = require("mysql");

var connection = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "f0R907pa55w0rd",
	database: "burgers_db"
});

connection.connect();

module.exports = connection;
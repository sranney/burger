use burgers_db;
insert into 
burgers 
(burger_name) 
values
("chicken bacon bleu cheese burger"),
("chorizo bacon cheese burger"),
("pimento cheese bacon cheese burger");